<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <!-- Полный перечень для атрибута type можно посмотреть здесь https://webref.ru/html/input/type -->
    <form action="form.php" method="post">
        <fieldset>
            <legend>Пример формы</legend>

            <p>
                <label for="first">Текстовый input</label><br>
                <input type="text" name="textField" id="first">
            </p>

            <p>
                Каким браузером в основном пользуетесь:<br>
                <input type="radio" name="browser" value="chrome"> Google Chrome<br>
                <input type="radio" name="browser" value="opera"> Opera<br>
                <input type="radio" name="browser" value="firefox"> Firefox
            </p>

            <p>
                Какая у вас ОС:<br>
                <input type="checkbox" name="os[]" value="windows"> Windows<br>
                <input type="checkbox" name="os[]" value="linux"> Linux<br>
                <input type="checkbox" name="os[]" value="macos"> macOS
            </p>

            <textarea cols="30" rows="5" name="textareaContent" maxlength="5"></textarea>

            <p>
                <select name="year[]" multiple size="2">
                    <option value="1">1981</option>
                    <option value="2" selected>1982</option>
                </select>
            </p>

            <p>
                <label for="chooseDate">Выберите дату:</label>
                <input id="chooseDate" type="date" name="mydate">
            </p>

            <p>
                <input required type="email" name="usermail">
            </p>

            <br>
            <input type="submit" value="Отправить">
        </fieldset>
    </form>

    <?php
        echo $_POST['textField'];
        echo '<br>';
        echo $_POST['browser'];
        echo '<br>';
        var_dump($_POST['os']);
        echo '<br>';
        echo $_POST['textareaContent'];
        echo '<br>';
        var_dump($_POST['year']);
        echo '<br>';
        echo $_POST['mydate'];
        echo '<br>';
        echo $_POST['usermail'];
    ?>
</body>
</html>

package com.flamexander.netty.servers.order;

import com.flamexander.netty.servers.discard.DiscardServerHandler;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;

public class OrderServer {
    public void run() throws Exception {
        class InboundTest extends ChannelInboundHandlerAdapter {
            private String msg;
            private boolean answer;

            public InboundTest(String msg, boolean answer) {
                this.msg = msg + "(In)";
                this.answer = answer;
            }

            @Override
            public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
                System.out.println(this.msg);
                if (answer) {
                    ctx.write("xxx");
                }
                ctx.fireChannelRead(msg);
            }
        }

        class OutboundTest extends ChannelOutboundHandlerAdapter {
            private String msg;

            public OutboundTest(String msg) {
                this.msg = msg + "(Out)";
            }

            @Override
            public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
                System.out.println(this.msg);
                ctx.writeAndFlush("1");
            }
        }

        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChannelInitializer<SocketChannel>() { // (4)
                        @Override
                        public void initChannel(SocketChannel ch) throws Exception {
                            ch.pipeline().addLast(new InboundTest("1", false), new InboundTest("2", true), new OutboundTest("2"), new OutboundTest("1"), new InboundTest("3", true));
                        }
                    })
                    .childOption(ChannelOption.SO_KEEPALIVE, true);
            ChannelFuture f = b.bind(8189).sync();
            f.channel().closeFuture().sync();
        } finally {
            workerGroup.shutdownGracefully();
            bossGroup.shutdownGracefully();
        }
    }

    public static void main(String[] args) throws Exception {
        new OrderServer().run();
    }
}

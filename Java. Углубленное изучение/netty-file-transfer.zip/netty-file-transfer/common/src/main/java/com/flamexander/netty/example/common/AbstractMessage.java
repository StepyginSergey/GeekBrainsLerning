package com.flamexander.netty.example.common;

import java.io.Serializable;

public abstract class AbstractMessage implements Serializable {
}
